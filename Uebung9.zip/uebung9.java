

//Leider habe ich nicht alle Abfragen geschafft, jedoch hoffe ich, dass es für eine positive Bewertung (trotz verspäteter Abgabe) reicht.

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

public class uebung9{

	public static void printNode(Node node, String prefix) {
		if (node == null) {
			return;
		}
		System.out.print(prefix + node.getNodeName());
		if (node.getNodeValue() != null) {
			System.out.println(":" + node.getNodeValue());
		} else {
			System.out.println();
		}
		
		NamedNodeMap cl = node.getAttributes();
		if (cl != null) {
			for (int i = 0; i < cl.getLength(); i++) {
				Node attr = cl.item(i);
				System.out.println(prefix + "\t" + attr.getNodeName() + "->"
						+ attr.getNodeValue());
			}
		}
		
		NodeList nl = node.getChildNodes();
		if (nl != null) {
			for (int i = 0; i < nl.getLength(); i++) {
				Node child = nl.item(i);
				printNode(child, prefix + "\t");
			}
		}
		
	}
	public static void main(String args[]) {
		//Einlesen der Datei
		Document doc = null;
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		try {
			DocumentBuilder builder = factory.newDocumentBuilder();
			doc = builder.parse(new File("src/customerOrders.xml"));
			
			/*
			* 9.Welches Gewicht hat LETSS insgesamt verschicken lassen?
			*/
			NodeList gewichtL = doc.getElementsByTagName("CustomerID");

			/*
			 * 5.Gibt es Kunden, die nicht aus den USA sind?
			 * Mittels Iterator die "Liste" durchgehn um die Länder zu bekommen
			 */
			NodeList land = doc.getElementsByTagName("Country");
			for (int i = 0; i < land.getLength(); i++) {
	         Node landListe = land.item(i);
	         if(landListe.getTextContent().equals("USA")){
	        	 System.out.println("USA");
	        }else{
	        	 System.out.println("!USA");
	        }
			}

			/*
			 * 1.Wie viele Kunden und wie viele Bestellungen sind gespeichert?
			 * Liste wird in Customer/Order gespeichert
			 * Davon wird die Lönge genommen, die ist in Anzahl/Customer gespeichert
			 */
			NodeList customer = doc.getElementsByTagName("Customer");
			NodeList order = doc.getElementsByTagName("Order");
			int anzahlCustomer = customer.getLength();
			int anzahlOrder = order.getLength();	
			System.out.println("Anzahl der Customer: " + anzahlCustomer);
			System.out.println("Anzahl der Order: " + anzahlOrder);
			
			/*
			 * 3.Wie lautet die vollständige Adresse von der Firma Lazy K Kountry Store?
			 * Childnodes von Item2
			 * Mittels Iterator die "Lsite" durchgehen um die gewünschten Informationen zu erhalten 
			 * 
			 */
			
			NodeList company = doc.getElementsByTagName("FullAddress").item(2).getChildNodes();
			for (int i = 0; i < company.getLength() ; i++){
				Node adresse = company.item(i);
				String textAdresse = adresse.getTextContent();
				System.out.println(textAdresse);
				
			}	
			/*
			 * 4.Gibt es Kunden, welche dieselbe dreistellige Vorwahl verwenden?
			 * Die Vorwahl ist von dem Land abhängig in dem der Kunde lebt.
			 * z.B.
			 * Deutschland +49
			 * Österreich  +43
			 * Polen 	   +48
			 * 
			 * Mittels Iterator die "Liste" durchgehen um die Nummern zu bekommen
			 * Das ist leider mein einziger unvollständiger Lösungsansatz
			 */
		NodeList number = doc.getElementsByTagName("Phone");
			for(int j=0; j< number.getLength();j++ ){
				Node phoneListe = number.item(j);
				//if()
			}
		
		
		/*
		 * 6.Welche(r) Kunde(n ) hatte(n ) die meisten Bestellungen?
		 */
		NodeList maxOrder = doc.getElementsByTagName("Order");
		for(int k=0; k< maxOrder.getLength(); k++){
			Node bestellungen = maxOrder.item(k);
		}
		
		
		/*
			 * 2.Welche CustomerID besitzt der vierte Kunde?
			 Cosutomer Lsite und Costumer vier werden gespeichert, Customer vier weil man die ID vom viertren Kudnen braucht.
			 *getNodeValue() --> MEthode hab ich von einem Mitschüler erfahren, jedoch weiß ich nur, dass sie eine Exception wirft.
			 */
			NodeList kunde4 = doc.getElementsByTagName("Customer");
			System.out.println(kunde4.item(3).getAttributes().getNamedItem("CustomerID"));
		
		}
		
		catch (SAXParseException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}